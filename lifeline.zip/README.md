# _{Portfolio website}_

#### _{Epicodus Independent Project #1}, {05.25.2018}_

#### By _**{Matt Smith}**_

## Description

_{This is our initial independent project: a portfolio website.  Click through to see the repositories I've been working on}_

## Setup/Installation Requirements

* _Clone this repository and view locally or view on the web.  This file is also saved as a .zip on my local drive: https://drive.google.com/open?id=1G1KgkFa2Lt9_zG-D9IAwABufGuHTmVfB_

## Known Bugs

_{I'm having issues uploading this project to github.  As a result, I haven't been able to clone or take screenshots of previous projects, so a placeholder image is in their place.  if you receive this project via email as a .zip file, it means I wasn't able to figure it out before the deadline}_

## Support and contact details

_{mattsmithereens@gmail.com}_

## Technologies Used

_{I used Bootstrap's CSS library and built this site in Atom}_

### License

*{This project is the work of Matt Smith.  While copyrights and the like will likely not be enforced, please contact me if you have any interest in using any part of this code.}*

Copyright (c) 2018 **_{Matt Smith, Epicodus}_**
